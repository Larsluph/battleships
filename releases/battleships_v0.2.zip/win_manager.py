#!/usr/bin/env python3
#-*- coding:utf-8 -*-

import tkinter as tk,os

def create_mainwindow():
    window = tk.Tk()
    window.title(f"Python Battleships")
    return window

def input_boat():
    global win,e,var
    win = tk.Tk()
    win.title("Python Battleships - Nbr Boats")
    
    tk.Label(win,text="How many boats do you want to play with :").grid(row=1,column=1)
    e = tk.Entry(win)
    e.grid(row=1,column=2)
    tk.Button(win,text="Validate!",command=callback_input).grid(row=2,column=1,columnspan=2)

    e.focus_force()
    win.mainloop()
    try:
        return var
    except:
        print('Action cancelled by user. Exiting...')
        raise SystemExit

def callback_input():
    global win,e,var
    try:
        var = int(e.get())
        win.destroy()
    except:
        e.delete(0, tk.END)
        e.insert(0, "use only numbers")

def input_coords(board_size,player_nbr,boat_id):
    global win, var_capacity, var_x, var_y, var_rotation, capacity, x, y, rotation, size
    size = board_size
    width = 48
    win = tk.Tk()
    win.title(f"Python Battleships - Player {player_nbr} - Place Boat {boat_id}")

    tk.Label(win,text="Enter the boat's capacity :").grid(row=1,column=1)
    capacity = tk.Entry(win,width=width)
    capacity.grid(row=1,column=2)

    tk.Label(win,text="Enter the x position of the boat :").grid(row=2,column=1)
    x = tk.Entry(win,width=width)
    x.grid(row=2,column=2)

    tk.Label(win,text="Enter the y position of the boat :").grid(row=3,column=1)
    y = tk.Entry(win,width=width)
    y.grid(row=3,column=2)
    
    tk.Label(win,text="Choose the boat's rotation :").grid(row=4,column=1)
    choices = ['Horizontal','Vertical']
    rotation = tk.StringVar(win)
    rotation.set(choices[0])
    tk.OptionMenu(win,rotation, *choices).grid(row=4,column=2)

    tk.Button(win,text="Validate!",command=callback_coords).grid(row=5,column=1,columnspan=2)

    capacity.focus_force()
    win.mainloop()

    try:
        result = (var_capacity,(var_x,var_y,var_rotation))
        del(var_capacity,var_x,var_y,var_rotation)
        return result
    except:
        print('Action cancelled by user. Exiting...')
        raise SystemExit

def callback_coords():
    global win, var_capacity, var_x, var_y, var_rotation, capacity, x, y, rotation, size
    errors = []
    try:
        var_capacity = int(capacity.get())
    except:
        var_capacity = None
        errors.append("capacity")

    try:
        var_x = int(x.get())
    except:
        var_x = None
        errors.append("x")

    try:
        var_y = int(y.get())
    except:
        var_y = None
        errors.append("y")
    
    if errors != []:
        del(var_capacity,var_x,var_y)
        print(errors)
        for error in errors:
            print(error)
            eval(error).delete(0, tk.END)
            eval(error).insert(0, "use only numbers")
        print()
    else:
        var_rotation = 0 if rotation.get() =='Horizontal' else 1

    if var_capacity < 1:
        errors.append("negative_capacity")
        capacity.delete(0, tk.END)
        capacity.insert(0, "the boat can't be empty nor have a negative capacity!")

    if var_capacity > 5:
        errors.append("too_long")
        capacity.delete(0,tk.END)
        capacity.insert(0, "the boat can't be longer than 5!")

    if not((size[0]+1)-var_capacity >= var_x > 0) and not(var_rotation):
        errors.append("x OOB")
        x.delete(0, tk.END)
        x.insert(0, "the boat must fit in the grid!")

    if not((size[1]+1)-var_capacity >= var_y > 0) and var_rotation:
        errors.append("y OOB")
        y.delete(0, tk.END)
        y.insert(0, "the boat must fit in the grid!")

    if errors == []:
        win.destroy()

if __name__ == '__main__':
    os.system("main_beta.py")
