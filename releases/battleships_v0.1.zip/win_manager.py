#!/usr/bin/env python3
#-*- coding:utf-8 -*-

import tkinter as tk

def create_mainwindow():
    window = tk.Tk()
    window.title(f"Python Battleships")
    return window

def input_boat():
    global win,e,var
    win = tk.Tk()
    win.title("Python Battleships - Nbr Boats")
    
    tk.Label(win,text="How many boats do you want to play with :").grid(row=1,column=1)
    e = tk.Entry(win)
    e.grid(row=1,column=2)
    tk.Button(win,text="Validate!",command=callback_input).grid(row=2,column=1,columnspan=2)

    e.focus_force()
    win.mainloop()
    try:
        return var
    except:
        print('Action cancelled by user. Exiting...')
        raise SystemExit

def callback_input():
    global win,e,var
    try:
        var = int(e.get())
        win.destroy()
    except:
        e.delete(0, tk.END)
        e.insert(0, "use only numbers")

def input_coords(board_size,player_nbr):
    global win, var_capacity, var_x, var_y, var_rotation, capacity, x, y, rotation, size
    size = board_size
    win = tk.Tk()
    win.title(f"Python Battleships - Place Boats")

    tk.Label(win, text=f"------------------------- Player {player_nbr} -------------------------").grid(row=1,column=1,columnspan=2)

    tk.Label(win,text="Enter the boat's capacity :").grid(row=2,column=1)
    capacity = tk.Entry(win)
    capacity.grid(row=2,column=2)

    tk.Label(win,text="Enter the x position of the boat :").grid(row=3,column=1)
    x = tk.Entry(win)
    x.grid(row=3,column=2)

    tk.Label(win,text="Enter the y position of the boat :").grid(row=4,column=1)
    y = tk.Entry(win)
    y.grid(row=4,column=2)
    
    tk.Label(win,text="Choose the boat's rotation :").grid(row=5,column=1)
    choices = ['Horizontal','Vertical']
    rotation = tk.StringVar(win)
    rotation.set(choices[0])
    tk.OptionMenu(win,rotation, *choices).grid(row=5,column=2)

    tk.Button(win,text="Validate!",command=callback_coords).grid(row=6,column=1,columnspan=2)

    capacity.focus_force()
    win.mainloop()

    try:
        result = (var_capacity,(var_x,var_y,var_rotation))
        del(var_capacity,var_x,var_y,var_rotation)
        return result
    except:
        print('Action cancelled by user. Exiting...')
        raise SystemExit

def callback_coords():
    global win, var_capacity, var_x, var_y, var_rotation, capacity, x, y, rotation, size
    errors = []
    try:
        var_capacity = int(capacity.get())
    except:
        var_capacity = None
        errors.append("capacity")

    try:
        var_x = int(x.get())
    except:
        var_x = None
        errors.append("x")

    try:
        var_y = int(y.get())
    except:
        var_y = None
        errors.append("y")
    
    if errors != []:
        del(var_capacity,var_x,var_y)
        print(errors)
        for error in errors:
            print(error)
            eval(error).delete(0, tk.END)
            eval(error).insert(0, "use only numbers")
        print()

    elif var_capacity < 1:
        capacity.delete(0, tk.END)
        capacity.insert(0, "the boat can't be empty nor have a negative capacity!")

    elif var_capacity > size[0] or var_capacity > size[1]:
        capacity.delete(0,tk.END)
        capacity.insert(0, "the boat won't fit in the grid!")

    elif not(size[0]-var_capacity >= var_x > 0):
        x.delete(0, tk.END)
        x.insert(0, "the boat must be on the grid!")

    elif not(size[1]-var_capacity >= var_y > 0):
        y.delete(0, tk.END)
        y.insert(0, "the boat must be on the grid!")

    else:
        var_rotation = 0 if rotation.get() =='Horizontal' else 1
        win.destroy()
