﻿#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os, time, tkinter as tk, custom_module, win_manager

class Board:
    def __init__(self,size,scale):
        self.size = size
        self.scale = scale
        self.status_var = tk.StringVar(value='{dmg_status}')
    
    def generate(self,window,player):
        if player == 1:
            self.txt = tk.Label(window, text="Your Playboard")
        else:
            self.txt = tk.Label(window, text="Enemy's Playboard")
        self.board = tk.Canvas(window, height=(self.size[0]+1)*self.scale, width=(self.size[1]+1)*self.scale, bg='#61c5ff')
    
    def draw_grid(self):
        self.board.create_line(self.scale, 3, (self.size[0]+1)*self.scale, 3, width=3, fill='black')
        self.board.create_line(3, self.scale, 3, (self.size[1]+1)*self.scale, width=3, fill='black')

        i=self.scale
        while i <= (self.size[0]+1)*self.scale:
            self.board.create_line(0,i,(self.size[0]+1)*self.scale,i,width=3,fill='black') # draw x lines
            i+=self.scale

        i=self.scale
        while i <= (self.size[1]+1)*self.scale:
            self.board.create_line(i,0,i,(self.size[1]+1)*self.scale,width=3,fill='black') # draw y lines
            i+=self.scale

        letter = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z".split(" ")

        for x in range(self.size[0]):
            self.board.create_text( ( (self.scale*x)+(self.scale*1.5), self.scale/2 ) , text=str(x+1) )
        
        for y in range(self.size[1]):
            self.board.create_text( ( self.scale/2, (self.scale*y)+(self.scale*1.5) ) , text=str(letter[y]) )

    def draw_boat(self,boat,coordinates):
        boat_color = "#808080"
        if coordinates[2] == 0:
            self.board.create_oval(coordinates[0]*self.scale, coordinates[1]*self.scale, (coordinates[0]*self.scale)+(boat.capacity*self.scale), (coordinates[1]*self.scale)+self.scale, outline=boat_color,fill=boat_color,width=1)
        else:
            self.board.create_oval(coordinates[0]*self.scale, coordinates[1]*self.scale, (coordinates[0]*self.scale)+self.scale, (coordinates[1]*self.scale)+(boat.capacity*self.scale), outline=boat_color,fill=boat_color,width=1)
    
    def draw_hit(self,boat,damaged_tile):
        if not(boat.coordinates[2]):
            self.board.create_line((boat.coordinates[0]*self.scale)+((damaged_tile+1)*self.scale), (boat.coordinates[1]*self.scale), (boat.coordinates[0]*self.scale)+((damaged_tile)*self.scale), (boat.coordinates[1]*self.scale)+self.scale,width=3,fill='#ff0000')
        else:
            self.board.create_line((boat.coordinates[0]*self.scale), (boat.coordinates[1]*self.scale)+((damaged_tile+1)*self.scale), (boat.coordinates[0]*self.scale)+self.scale, (boat.coordinates[1]*self.scale)+((damaged_tile)*self.scale),width=3,fill='#ff0000')
    
    def draw_drown(self,boat):
        if not(boat.coordinates[2]):
            for x in range(boat.capacity):
                self.board.create_line((boat.coordinates[0]*self.scale)+((x)*self.scale), (boat.coordinates[1]*self.scale), (boat.coordinates[0]*self.scale)+((x+1)*self.scale), (boat.coordinates[1]*self.scale)+self.scale,width=3,fill='#ff0000')
        else:
            for x in range(boat.capacity):
                self.board.create_line((boat.coordinates[0]*self.scale), (boat.coordinates[1]*self.scale)+((x)*self.scale), (boat.coordinates[0]*self.scale)+self.scale, (boat.coordinates[1]*self.scale)+((x+1)*self.scale),width=3,fill='#ff0000')
    
    def draw_miss(self,coordinates):
        self.board.create_line((coordinates[0]-1)*self.scale,(coordinates[1]-1)*self.scale,coordinates[0]*self.scale,coordinates[1]*self.scale,width=3,fill='#0c00ed')
        self.board.create_line((coordinates[0])*self.scale,(coordinates[1]-1)*self.scale,(coordinates[0]-1)*self.scale,coordinates[1]*self.scale,width=3,fill='#0c00ed')
    
    def build_win(self,window,player):
        status = tk.Label(window,textvariable=self.status_var)
        if player == 1:
            self.txt.grid(row=1,column=1)
            self.board.grid(row=2,column=1)
            status.grid(row=3,column=1,columnspan=2)
        else:
            self.txt.grid(row=1,column=2)
            self.board.grid(row=2,column=2)
            status.grid(row=3,column=1,columnspan=2)
    
class Boat:
    def __init__(self,capacity):
        self.capacity = capacity
        self.hp = capacity
        self.damages = list()
        for _ in range(capacity):
            self.damages.append(1)
    
    def set_boat(self,coordinates):
        self.coordinates = coordinates # (x,y,rotation)
    
    def hit(self,board,damaged_tile):
        self.damages[damaged_tile] = 0
        self.hp -= 1
        
        board.draw_hit(self,damaged_tile)
        board.board.update()

class Player:
    def __init__(self,boats):
        self.boatnbr = boats
        self.boats = []
        self.stats = {
            "shots":0,
            "miss":0,
            "hits":0,
            "drown":0
        }

def solo():
    os.system('cls')

    boatnbr = win_manager.input_boat()

    p1 = Player(boatnbr)
    p2 = Player(boatnbr)

    size = (10,10)

    for _ in range(boatnbr):
        boat = win_manager.input_coords(size,1)
        p1.boats.append([Boat(boat[0]),boat[1]])

    for _ in range(boatnbr):
        boat = win_manager.input_coords(size,2)
        p2.boats.append([Boat(boat[0]),boat[1]])

    window = win_manager.create_mainwindow() # create a window

    p1_playboard = Board(size,50) # create a playboard
    p2_playboard = Board(size,50)

    p1_playboard.generate(window,1) # create a canvas
    p2_playboard.generate(window,2)

    for boat in p1.boats:
        boat[0].set_boat(boat[1]) # set all boats' coordinates
        p1_playboard.draw_boat(boat[0],boat[1]) # draw them all

    for boat in p2.boats:
        boat[0].set_boat(boat[1])
        p2_playboard.draw_boat(boat[0],boat[1])

    p1_playboard.draw_grid()
    p2_playboard.draw_grid()

    p1_playboard.build_win(window,1) # finally build the window w/ the playboard
    p2_playboard.build_win(window,2)

    window.mainloop()

def main_menu():
    while True:
        exec(custom_module.utilities.menu_generator(
            "Battleships",
            [],
            ["Play", "Exit"],
            ["solo()","raise SystemExit"]
            ))
            
if __name__ == '__main__':
    main_menu()
