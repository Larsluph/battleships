In this zip, you'll find all you need to play the battleship game by Larsluph.
To launch the game, you have to execute the "main.py" file with the "python.exe" file that comes with the installed python version.

Here's a list of the files included.
    Note that all of these files have to be in the same empty folder to avoid crashs and errors.

- folder "custom_module" is required to launch the game.
-  file  "battleships.config" is the configuration file of the game. This is where you can edit the game's settings.
-  file  "main.py" is the file that you need to launch with the provided python version.
-  file  "python-3.7.4-webinstall.exe" is the installer of the required python version.
            You'll have to run it if you haven't already installed this version. (install with default values).
-  file  "win_manager.py" is an addon for the game and is required to launch it.


TL;DR
install provided python version if it's not already done. Then, launch main.py with (python_folder)/python.exe