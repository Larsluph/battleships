#!usr/bin/env python
# -*- coding:utf-8 -*-
"a package by ThePythonDev w/ useful modules"

from custom_module import chronometer
from custom_module import decryptor
from custom_module import file_manager
from custom_module import math_calc
from custom_module import time_calc
from custom_module import utilities