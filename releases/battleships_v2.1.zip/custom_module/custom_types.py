#!/usr/bin/env python3
#-*- coding: utf-8 -*-

class custom_str(str):
  def __init__(self,data):
    self.value = str(data)

  def find_all(self,substring):
    print(f"find_all({self.value},{substring})")
