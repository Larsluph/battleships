﻿#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import custom_module
import os
import string
import time
import tkinter as tk

import win_manager


class Board:
    def __init__(self,size,scale):
        self.size = size
        self.scale = scale
        self.status_var = tk.StringVar(value='{dmg_status}')

    def generate(self,window,player):
        if player == 1:
            self.txt = "Your Playboard"
        else:
            self.txt = "Enemy's Playboard"

        self.txt = tk.Label(window, text=self.txt)
        self.board = tk.Canvas(window, height=(self.size[0]+1)*self.scale, width=(self.size[1]+1)*self.scale, bg='#61c5ff')
    
    def draw_grid(self):
        self.board.create_line(self.scale, 3, (self.size[0]+1)*self.scale, 3, width=3, fill='black')
        self.board.create_line(3, self.scale, 3, (self.size[1]+1)*self.scale, width=3, fill='black')

        i=self.scale
        while i <= (self.size[0]+1)*self.scale:
            self.board.create_line(0,i,(self.size[0]+1)*self.scale,i,width=3,fill='black') # draw x lines
            i+=self.scale

        i=self.scale
        while i <= (self.size[1]+1)*self.scale:
            self.board.create_line(i,0,i,(self.size[1]+1)*self.scale,width=3,fill='black') # draw y lines
            i+=self.scale

        bold_font = ("Helvetica", 18, "bold")
        for x in range(self.size[0]):
            self.board.create_text( ( (self.scale*x)+(self.scale*1.5), self.scale/2 ) , text=str(x+1) ,font=bold_font)
        
        for y in range(self.size[1]):
            self.board.create_text( ( self.scale/2, (self.scale*y)+(self.scale*1.5) ) , text=letter[y] ,font=bold_font)

    def draw_boat(self,boat):
        boat_color = "#808080"
        if boat.base_coordinates[2] == 0:
            self.board.create_oval(boat.base_coordinates[0]*self.scale, boat.base_coordinates[1]*self.scale, (boat.base_coordinates[0]*self.scale)+(boat.capacity*self.scale), (boat.base_coordinates[1]*self.scale)+self.scale, outline=boat_color,fill=boat_color,width=1)
        else:
            self.board.create_oval(boat.base_coordinates[0]*self.scale, boat.base_coordinates[1]*self.scale, (boat.base_coordinates[0]*self.scale)+self.scale, (boat.base_coordinates[1]*self.scale)+(boat.capacity*self.scale), outline=boat_color,fill=boat_color,width=1)
    
    def draw_hit(self,coordinates):
        self.board.create_line((coordinates[0])*self.scale,(coordinates[1]+1)*self.scale,(coordinates[0]+1)*self.scale,coordinates[1]*self.scale,width=3,fill='#ff0000')
    
    def draw_drown(self,boat):
        if not(boat.base_coordinates[2]):
            for x in range(boat.capacity):
                self.board.create_line((boat.base_coordinates[0]*self.scale)+((x)*self.scale), (boat.base_coordinates[1]*self.scale), (boat.base_coordinates[0]*self.scale)+((x+1)*self.scale), (boat.base_coordinates[1]*self.scale)+self.scale,width=3,fill='#ff0000')
        else:
            for x in range(boat.capacity):
                self.board.create_line((boat.base_coordinates[0]*self.scale), (boat.base_coordinates[1]*self.scale)+((x)*self.scale), (boat.base_coordinates[0]*self.scale)+self.scale, (boat.base_coordinates[1]*self.scale)+((x+1)*self.scale),width=3,fill='#ff0000')
    
    def draw_miss(self,coordinates):
        self.board.create_line((coordinates[0]+1)*self.scale,(coordinates[1]+1)*self.scale,coordinates[0]*self.scale,coordinates[1]*self.scale,width=3,fill='#0c00ed')
        self.board.create_line((coordinates[0])*self.scale,(coordinates[1]+1)*self.scale,(coordinates[0]+1)*self.scale,coordinates[1]*self.scale,width=3,fill='#0c00ed')
    
class Boat:
    def __init__(self,properties):
        self.capacity = properties[0]
        self.base_coordinates = properties[1]
        self.list_coordinates = []
        self.hp = self.capacity
        self.damages = list()
        for _ in range(self.capacity):
            self.damages.append(1)

        for x in range(self.capacity):
            if self.base_coordinates[2] == 0:
                self.list_coordinates.append( (self.base_coordinates[0]+x, self.base_coordinates[1]) )
            else:
                self.list_coordinates.append( (self.base_coordinates[0], self.base_coordinates[1]+x) )
    
    def hit(self,player,board,damaged_tile):
        self.damages[damaged_tile] = 0
        self.hp -= 1
        player.hp -= 1

        board.draw_hit(self.list_coordinates[damaged_tile])

class Player:
    def __init__(self,id,boatnbr):
        self.id = id
        self.boatnbr = boatnbr
        self.hp = 0
        self.boats = []
        self.list_coordinates = []
        self.list_shots = []
        self.stats = {
            "shots":0,
            "miss":0,
            "hits":0,
            "drown":0
            }
            
    def create_boards(self,size):
        self.board_player = Board(size,50)
        self.board_opponent = Board(size,50)

def show_win(player,opponent):
    opponent.board_player.txt.grid_remove()
    opponent.board_player.board.grid_remove()
    opponent.board_player.status.grid_remove()

    opponent.board_opponent.txt.grid_remove()
    opponent.board_opponent.board.grid_remove()

    player.board_player.txt.grid()
    player.board_player.board.grid()
    player.board_player.status.grid()

    player.board_opponent.txt.grid()
    player.board_opponent.board.grid()

def hide_win(player,opponent):
    player.board_player.txt.grid_remove()
    player.board_player.board.grid_remove()
    player.board_player.status.grid_remove()
    player.board_opponent.txt.grid_remove()
    player.board_opponent.board.grid_remove()

    opponent.board_player.txt.grid_remove()
    opponent.board_player.board.grid_remove()
    opponent.board_player.status.grid_remove()
    opponent.board_opponent.txt.grid_remove()
    opponent.board_opponent.board.grid_remove()

def multi_local():
    os.system('cls')

    boatnbr = win_manager.input_boat()

    p1 = Player(1,boatnbr)
    p2 = Player(2,boatnbr)

    for p in ["p1","p2"]:
        for i in range(boatnbr):
            boat = win_manager.input_coords(p[1],i+1)
            boat_obj = Boat(boat)

            run = True
            while run:
                run = False
                x = 0
                while x < len(boat_obj.list_coordinates):
                    if boat_obj.list_coordinates[x] in eval(p).list_coordinates:
                        run = True
                        win = tk.Tk()
                        tk.Label(win,text="this boat is on another one").pack()
                        tk.Label(win,text="you can only place a boat in the water").pack()
                        ok=tk.Button(win,text="OK",command=win.destroy)
                        ok.pack()
                        ok.focus_force()
                        win.mainloop()
                        boat = win_manager.input_coords(p[1],i+1)
                        boat_obj = Boat(boat)
                    x += 1
            
            eval(p).boats.append(boat_obj)
            eval(p).list_coordinates += boat_obj.list_coordinates
            eval(p).hp += boat[0]
    
    ### game started

    window = win_manager.create_mainwindow()

    p1.create_boards(size)
    p2.create_boards(size)

    p1.board_player.generate(window,1) # create a canvas
    p1.board_opponent.generate(window,2)
    
    p2.board_player.generate(window,1)
    p2.board_opponent.generate(window,2)

    for boat in p1.boats:
        p1.board_player.draw_boat(boat) # draw them all

    for boat in p2.boats:
        p2.board_player.draw_boat(boat) # draw them all

    p1.board_player.draw_grid()
    p1.board_opponent.draw_grid()
    p2.board_player.draw_grid()
    p2.board_opponent.draw_grid()

    p1.board_player.txt.grid(row=1,column=1)
    p1.board_player.board.grid(row=2,column=1)
    p1.board_player.status = tk.Label(window,textvariable=p1.board_player.status_var,fg="#000000")
    p1.board_player.status.grid(row=3,column=1,columnspan=2)

    p1.board_opponent.txt.grid(row=1,column=2)
    p1.board_opponent.board.grid(row=2,column=2)

    p2.board_player.txt.grid(row=4,column=1)
    p2.board_player.board.grid(row=5,column=1)
    p2.board_player.status = tk.Label(window,textvariable=p2.board_player.status_var,fg="#000000")
    p2.board_player.status.grid(row=6,column=1,columnspan=2)

    p2.board_opponent.txt.grid(row=4,column=2)
    p2.board_opponent.board.grid(row=5,column=2)

    show_win(p1,p2)
    hide_win(p1,p2)
    window.update()

    current_player = 1
    while p1.hp != 0 and p2.hp != 0:
        player = "p"+str(current_player)
        opponent = "p"+str(int(not(current_player-1))+1)
        window.title(f"Python Battleships - Player {player[1]}")

        win_manager.popup(window,f"Player {player[1]}'s turn")

        show_win(eval(player),eval(opponent))

        ### user action
        target = win_manager.input_target(window,player[1])
        while target in eval(player).list_shots:
            win_manager.popup(window, f"you already shot at that point")
            target = win_manager.input_target(window,player[1])

        print(target)

        eval(player).stats["shots"] += 1
        eval(player).list_shots.append(target)
        if target in eval(opponent).list_coordinates:
            eval(player).stats["hits"] += 1
            
            for boat in eval(opponent).boats:
                if target in boat.list_coordinates:
                    break
            if boat.damages[boat.list_coordinates.index(target)] != 0:
                boat.hit( eval(opponent), eval(opponent).board_player, boat.list_coordinates.index(target) )
                eval(player).board_opponent.draw_hit(boat.list_coordinates[boat.list_coordinates.index(target)])
                eval(player).board_player.status_var.set("HIT!")
                if boat.hp == 0:
                    eval(player).board_player.status_var.set("DROWN!")
                    eval(opponent).board_player.draw_drown(boat)
                    eval(player).board_opponent.draw_drown(boat)
        else:
            eval(player).board_player.status_var.set("MISS!")
            eval(player).stats["miss"] += 1
            eval(player).board_opponent.draw_miss(target)
            eval(opponent).board_player.draw_miss(target)

        window.update()
        win_manager.popup(window,eval(player).board_player.status_var.get())

        hide_win(eval(player),eval(opponent))

        current_player = int(not(current_player-1))+1

    window.destroy()

    print("GAME IS FINISHED!")
    if p1.hp == 0 and p2.hp != 0:
        print("PLAYER 2 WINS!")
    elif p1.hp != 0 and p2.hp == 0:
        print("PLAYER 1 WINS!")
    elif p1.hp == 0 and p2.hp == 0:
        print("IT'S A DRAW!")
    os.system("pause")
    
def main_menu():
    while True:
        exec(custom_module.utilities.menu_generator(
            "Battleships",
            [],
            ["Play", "Exit"],
            ["multi_local()","raise SystemExit"])
        )

letter = list(string.ascii_uppercase)
size = (10,10)

if __name__ == '__main__':
    main_menu()
